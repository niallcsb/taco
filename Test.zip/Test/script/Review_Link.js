class Review_Link {
  constructor(
    headline,
    subhead,
    link,
    image
  ) {
    this.headline = headline;
    this.subhead = subhead;
    this.link = link;
    this.image = image;
  }
}

export default Review_Link;
